import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class blueberry here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class blueberry extends Fruits
{
    /**
     * Act - do whatever the blueberry wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        moveDown();
    }
}

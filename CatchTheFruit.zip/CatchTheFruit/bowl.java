import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class bowl here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class bowl extends Methods
{
     MyWorld fruits;
     Methods FRUIT_SPEED;
     

    
    /**
     * Act - do whatever the bowl wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    private GreenfootSound playSound = new GreenfootSound("explosion.wav");
    public void act()
    {
        eat();
          if(Greenfoot.isKeyDown("left")) {
            moveLeft();
        } else if(Greenfoot.isKeyDown("right")) {
            moveRight();
        }
    }
    GreenfootImage image1 = new GreenfootImage ("bowl2.png");
    public bowl()
    {
        image1.scale(156,90);
        setImage(image1);
    }
    
    public void eat()
    {
        if(canSee(apple.class))
        {
            eat(apple.class);
            fruits.score++;
        }
        if(canSee(banana.class))
        {
            eat(banana.class);
            fruits.score++;
        }
        if(canSee(blueberry.class))
        {
            eat(blueberry.class);
            fruits.score++;
        }
        if(canSee(cherries.class))
        {
            eat(cherries.class);
            fruits.score++;
        }
        if(canSee(orange.class))
        {
            eat(orange.class);
            fruits.score++;
        }
        if(canSee(bomb.class))
        {
            eat(bomb.class);
            Greenfoot.stop();
            getWorld().showText("Game Over", getWorld().getWidth() / 2, getWorld().getHeight() / 2);
            int score= 0;
            playSound.play();
        }
    }
}

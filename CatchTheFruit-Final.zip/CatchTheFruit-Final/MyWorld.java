import greenfoot.*;
public class MyWorld extends World
{
    private GreenfootSound catchSound = new GreenfootSound("negativebeeps.wav");
    private GreenfootSound watchSound = new GreenfootSound("dropsound.wav");
    private GreenfootSound callSound = new GreenfootSound("success.wav");
    public static int score = 0;
    public int p = 1; // Initial number of fruits to add
    
    private void checkForGameOver() {
        for (Object obj : getObjects(Fruits.class)) {
            Fruits fruit = (Fruits) obj;
            
            if (fruit.getY() >= getHeight() - fruit.getImage().getHeight() / 2) {
                score = 0;
                Greenfoot.stop();
                
                showText("Game Over", getWidth() / 2, getHeight() / 2);
                catchSound.play();
            }
        }
    }

    public MyWorld() throws InterruptedException
    {    
        super(700, 400, 1); 
        startUp();
        prepare();
    }
    GreenfootImage bowl = new GreenfootImage("game_over_bowl.png");
    public void act()
    {
        showText("Score: " + score, 50, 25);
        if (score == 0)
        {
            bowl bowl = (bowl) getObjects(bowl.class).get(0);
            bowl.setImage("bowl23.png");
            bowl.getImage().scale(156,90);
        }
        if (score == 10)
        {
            bowl bowl = (bowl) getObjects(bowl.class).get(0);
            bowl.setImage("bowl2.png");
            bowl.getImage().scale(156,90);
        }
        if (score == 20)
        {
            bowl bowl = (bowl) getObjects(bowl.class).get(0);
            bowl.setImage("bowl223.png");
            bowl.getImage().scale(156,90);
        }
        if(score == 30)
        {
            Greenfoot.stop();
            score = 0;
            showText("You Win!!", getWidth() / 2, getHeight() / 2);
            callSound.play();
            bowl bowl = (bowl) getObjects(bowl.class).get(0);
            bowl.setImage("game_over_bowl.png");
        }
        if (getObjects(Fruits.class).size() == 0) {
            try
            {
                addFruit();
            }
            catch (InterruptedException ie)
            {
                ie.printStackTrace();
            }
            watchSound.play();
        }
        checkForGameOver();
    }

    public void startUp() throws InterruptedException
    {
        addObject(new bowl(), 350, 350);
        addFruit();
    }

    public void addFruit() throws InterruptedException {
        int f = 0;
        while (f < p) {
            int x = Greenfoot.getRandomNumber(6) + 64;
            switch (x) {
                case 64:
                    addObject(new bomb(), Greenfoot.getRandomNumber(600), 20);
                    break;
                case 65:
                    addObject(new apple(), Greenfoot.getRandomNumber(600), 20);
                    break;
                case 66:
                    addObject(new banana(), Greenfoot.getRandomNumber(600), 20);
                    break;
                case 67:
                    addObject(new blueberry(), Greenfoot.getRandomNumber(600), 20);
                    break;
                case 68:
                    addObject(new cherries(), Greenfoot.getRandomNumber(600), 20);
                    break;
                case 69:
                    addObject(new orange(), Greenfoot.getRandomNumber(600), 20);
                    break;
                
            }
            f++;
        }
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Methods.WALKING_SPEED = 8.0;
        Methods.FRUIT_SPEED = 2.0;
        score=0;
    }
}

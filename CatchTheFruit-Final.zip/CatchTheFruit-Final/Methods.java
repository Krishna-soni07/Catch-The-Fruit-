import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Methods here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Methods extends Actor
{
    public static double WALKING_SPEED = 8.0;
    public static double FRUIT_SPEED = 2.0;
    
    /**
     * Act - do whatever the Methods wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }

    /**
     * Try to eat an object of class 'clss'. This is only successful if there
     * is such an object where we currently are. Otherwise this method does
     * nothing.
     */
    public void eat(Class clss)
    {
            FRUIT_SPEED += 0.15;
            WALKING_SPEED += 0.05;
        
    }

    /**
     * Return true if we can see an object of class 'clss' right where we are. 
     * False if there is no such object here.
     */
    public boolean canSee(Class clss)
    {
        Actor actor = getOneObjectAtOffset(0, 0, clss);
        return actor != null;        
    }

    /**
     * Move forward in the current direction.
     */
    public void move()
    {
        
    }

    /**
     * Move the actor downward.
     */
    public void moveDown()
    {
        int x = getX(); // Get the current x-coordinate
        int y = getY() + (int) FRUIT_SPEED; // Calculate the new y-coordinate by adding the walking speed

        setLocation(x, y); // Set the new location
    }
        /**
     * Move the actor left.
     */
    public void moveLeft()
    {
        int x = getX() - (int) WALKING_SPEED; // Calculate the new x-coordinate for moving left
        setLocation(x, getY()); // Set the new location
    }

    /**
     * Move the actor right.
     */
    public void moveRight()
    {
        int x = getX() + (int) WALKING_SPEED; // Calculate the new x-coordinate for moving right
        setLocation(x, getY()); // Set the new location
    }
}


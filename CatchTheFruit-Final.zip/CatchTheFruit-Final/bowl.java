import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class bowl here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class bowl extends Methods
{
     MyWorld fruits;
     Methods FRUIT_SPEED;
     

    
    /**
     * Act - do whatever the bowl wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    private GreenfootSound playSound = new GreenfootSound("explosion.wav");
    public void act()
    {
        eat();
          if(Greenfoot.isKeyDown("left")) {
            moveLeft();
        } else if(Greenfoot.isKeyDown("right")) {
            moveRight();
        }
    }
    GreenfootImage image1 = new GreenfootImage ("bowl23.png");
    public bowl()
    {
        image1.scale(156,90);
        setImage(image1);
    }
    
    public void eat()
    {
        if(isTouching(apple.class))
        {
            eat(apple.class);
            removeTouching(apple.class);
            fruits.score++;
        }
        if(isTouching(banana.class))
        {
            eat(banana.class);
            removeTouching(banana.class);
            fruits.score++;
        }
        if(isTouching(blueberry.class))
        {
            eat(blueberry.class);
            removeTouching(blueberry.class);
            fruits.score++;
        }
        if(isTouching(cherries.class))
        {
            eat(cherries.class);
            removeTouching(cherries.class);
            fruits.score++;
        }
        if(isTouching(orange.class))
        {
            eat(orange.class);
            removeTouching(orange.class);
            fruits.score++;
        }
        if(isTouching(bomb.class))
        {
            eat(bomb.class);
            Greenfoot.stop();
            getWorld().showText("Game Over", getWorld().getWidth() / 2, getWorld().getHeight() / 2);
            int score= 0;
            playSound.play();
        }
    }
}
